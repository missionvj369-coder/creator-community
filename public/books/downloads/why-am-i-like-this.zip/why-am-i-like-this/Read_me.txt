Why Am I Like This?

Extract this folder and open why-am-i-like-this.html in your browser. The illustrations, text, fonts and reading controls are included in the HTML file.
