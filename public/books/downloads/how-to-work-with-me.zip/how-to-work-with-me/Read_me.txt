How to Work With Me

Extract this folder and open how-to-work-with-me.html in your browser. The illustrations, text, fonts and reading controls are included in the HTML file.
