The Body You Live In

Extract this folder and open body-you-live-in.html in your browser. The illustrations, text, fonts and reading controls are included in the HTML file.
