The Human Journey

Extract this folder and open human-journey.html in your browser. The illustrations, text, fonts and reading controls are included in the HTML file.
