Why Can’t I Switch Off?

Extract this folder and open switch-off.html in your browser. The illustrations, text, fonts and reading controls are included in the HTML file.
